package rain;

import java.awt.Color;

import javax.swing.JFrame;

public class Main {

	public Main() {
		
		JFrame frame = new  JFrame();
		Rain gamepanel = new Rain();
		//Rain gamepanel1 = new Rain();
		//Rain gamepanel2 = new Rain();
		frame.setBackground(Color.GREEN);
		
		frame.add(gamepanel);//frame.add(gamepanel1);frame.add(gamepanel2);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("SNAKECOODING");
		
		
		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
	public static void main(String[] args) {
		
		new Main();

	}

}
