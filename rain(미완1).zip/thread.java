//package rain;
//
//import java.util.ArrayList;
//
//public class thread implements Runnable{
//
//	private Thread thread;
//	private BodyPart b;
//	private ArrayList<BodyPart> rain;
//	
//	private int xCoor = 10, yCoor = 10, size = 10;
//	private int ticks = 0;
//	private boolean running;
//	
//	public thread() {
//		rain = new ArrayList<BodyPart>();
//	}
//	
//	
//	
//	
//	
//	
//	@Override
//	public void run() {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
