
package rain3;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Drop2 {
	private Random random;
	private int x,y,xSpeed;
	
	public Drop2(){
		random = new Random();
		
		
		x= -random.nextInt(200);
		y= random.nextInt(Main.height);
		
		
		xSpeed = random.nextInt(10)+1;
		
		
	}
	
	public void update() {
		x+= xSpeed;
		if(x>Main.width) {
			x = -random.nextInt(300);
			RightThread.ticks2++;
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.yellow);
		g.fillRect(x,y,20,5);
	}
}
