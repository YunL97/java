package testPtj;

public class TranspotationWalk {
	public void move() {
		System.out.println("�̵�");
	}
}
