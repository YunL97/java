package org.spring.dao;

import java.util.List;

import org.spring.dto.BoardVO;
import org.spring.dto.MemberVO;


 
public interface MemberDAO {
    
	//목록 출력
    public List<BoardVO> list() throws Exception;
    
    //회원가입 작성
    public void write(MemberVO memberVO) throws Exception;
    
    //로그인
    public MemberVO login(MemberVO membervo) throws Exception;
    
    //게시글작성
    public void boardwrite(BoardVO boardvo) throws Exception;
    
 // 게시물 조회
    public BoardVO read(int id) throws Exception;
    
    public void update(BoardVO boardvo) throws Exception;
    
    public void delete(int id) throws Exception;

	
}
