package org.spring.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.spring.dto.BoardVO;
import org.spring.dto.MemberVO;
import org.springframework.stereotype.Repository;



@Repository
public class MemberDAOImpl implements MemberDAO {
 
    @Inject
    private SqlSession sqlSession;
    
    private static final String Namespace = "org.spring.mapper.memberMapper";
    
    @Override
    public List<BoardVO> list() throws Exception {
 
        return sqlSession.selectList(Namespace+".list");
    }
    
    
    // 회원가입 작성
 	@Override
 	public void write(MemberVO memberVO) throws Exception {
 		sqlSession.insert(Namespace+".insert", memberVO);
 	}
 	
 	//로그인
 	@Override
 	public MemberVO login(MemberVO memberVO) throws Exception{
 		return sqlSession.selectOne(Namespace+".login",memberVO);
 	}


 	//게시글 작성
	@Override
	public void boardwrite(BoardVO boardVO) throws Exception {
		// TODO Auto-generated method stub
		sqlSession.insert(Namespace+".write", boardVO);
		
	}
	
	public BoardVO read(int id) throws Exception {
		
		return sqlSession.selectOne(Namespace+".read", id);
	}
	
	 public void update(BoardVO boardvo) throws Exception {
		sqlSession.update(Namespace+".update",boardvo);
	 }	
	 
	    public void delete(int id) throws Exception{
	    	sqlSession.delete(Namespace+".delete",id);
	    }

}


