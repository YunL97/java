package org.spring.sample;

import java.util.List;
import java.util.Locale;
 
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spring.dto.BoardVO;
import org.spring.dto.MemberVO;
import org.spring.service.MemberService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
 

 
/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
    
    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
    
    @Inject
    private MemberService service;
   
    
    /**
     * Simply selects the home view to render by returning its name.
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home(Locale locale, Model model) throws Exception{
 
    	
    	
        logger.info("home");
        
       return "home";
 
        
    }
    
    @RequestMapping(value = "board/list", method = RequestMethod.GET)
    public void list(Model model) throws Exception {
    
    	
    	logger.info("get list");
     
     List<BoardVO> list = service.list();
     
     model.addAttribute("list", list);
    }
 // 회원가입화면
 	@RequestMapping(value = "/board/writeView", method = RequestMethod.GET)
 	public void writeView() throws Exception{
 		logger.info("writeView");
 		
 	}
 	
 	
 	// 회원가입
 	@RequestMapping(value = "/board/signwrite", method = RequestMethod.POST)
 	public String write(MemberVO memberVO) throws Exception{
 		logger.info("write");
 		
 		service.write(memberVO);
 		
 		return "redirect:/";
 	}
 	
 // 로그인
 	@RequestMapping(value = "/board/login", method = RequestMethod.POST)
 	public String login(MemberVO vo, HttpServletRequest req,RedirectAttributes rttr) throws Exception {
 	 logger.info("post login");
 	 
 	 HttpSession session = req.getSession();
 	 
 	 MemberVO login = service.login(vo);
 	 
 	 if(login == null) {
 	  session.setAttribute("member", null);  
 	  rttr.addFlashAttribute("msg", false);
 	 } else {
 	  session.setAttribute("member", login);
 	 }
 	   
 	return "redirect:/";
 	}
 	
 // 글 작성 get
 	 @RequestMapping(value = "board/write", method = RequestMethod.GET)
 	 public void getWrite() throws Exception {
 	  logger.info("get write");
 	 }

 	 // 글 작성 post
 	 @RequestMapping(value = "board/write", method = RequestMethod.POST)
 	 public String postWrite(BoardVO boardvo) throws Exception {
 	  logger.info("post write");
 	  
 	  service.boardwrite(boardvo);
 	  
 	  return "redirect:/";
 	 }
 	 
 	// 로그아웃
 	@RequestMapping(value = "board/logout", method = RequestMethod.GET)
 	public String logout(HttpSession session) throws Exception {
 	 logger.info("get logout");
 	 
 	 session.invalidate();
 	   
 	 return "redirect:/";
 	}
 	
 // 게시판 조회
 	@RequestMapping(value = "board/detaillist", method = RequestMethod.GET)
 	public void read(BoardVO boardVO, Model model) throws Exception{
 		logger.info("read");
 		
 		model.addAttribute("read", service.read(boardVO.getId()));
 		
 		//return "board/detaillist";
 	}
 	
 // 게시판 수정뷰
 	@RequestMapping(value = "/updateView", method = RequestMethod.GET)
 	public String updateView(BoardVO boardVO, Model model) throws Exception{
 		logger.info("updateView");
 		
 		model.addAttribute("update", service.read(boardVO.getId()));
 		
 		return "board/updateView";
 	}
 	
 	// 게시판 수정
 	@RequestMapping(value = "/update", method = RequestMethod.POST)
 	public String update(BoardVO boardVO) throws Exception{
 		logger.info("update");
 		
 		service.update(boardVO);
 		
 		return "redirect:/board/list";
 	}

 	// 게시판 삭제
 	@RequestMapping(value = "/delete", method = RequestMethod.POST)
 	public String delete(BoardVO boardVO) throws Exception{
 		logger.info("delete");
 		
 		service.delete(boardVO.getId());
 		
 		return "redirect:/board/list";
 	}
    
}


