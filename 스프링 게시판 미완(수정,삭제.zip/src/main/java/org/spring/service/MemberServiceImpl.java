package org.spring.service;

import java.util.List;

import javax.inject.Inject;

import org.spring.dao.MemberDAO;
import org.spring.dto.BoardVO;
import org.spring.dto.MemberVO;
import org.springframework.stereotype.Service;
 

 
@Service
public class MemberServiceImpl implements MemberService {
 
    @Inject
    private MemberDAO dao;
    
    
    @Override
    public List<BoardVO> list() throws Exception {
 
        return dao.list();
    }
    
 // 회원가입 작성
 	@Override
 	public void write(MemberVO memberVO) throws Exception {
 		dao.write(memberVO);
 	}

 	
 	//로그인
	@Override
	public MemberVO login(MemberVO memberVO) throws Exception {
		// TODO Auto-generated method stub
		return dao.login(memberVO);
	}

	
	@Override
	public void boardwrite(BoardVO boardVO) throws Exception {
		// TODO Auto-generated method stub
		dao.boardwrite(boardVO);
	}
	// 게시물 목록 조회
	@Override
	public BoardVO read(int id) throws Exception {

		return dao.read(id);
	}
	
	   public void update(BoardVO boardvo) throws Exception{
		   dao.update(boardvo);
	   }
	    
	    public void delete(int id) throws Exception{
	       dao.delete(id);
	    }
 
}


