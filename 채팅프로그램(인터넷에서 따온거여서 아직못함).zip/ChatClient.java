package chat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatClient extends JFrame implements ActionListener, Runnable{
	
	private Socket socket;
	private BufferedReader br;
	private PrintWriter pw;
	
	public JLabel jlName,connecter,lbsu;
	private JTextField txtName, txtContent;
	private JButton btnLogin, btnLogout, btnOk;
	private JTextArea jtContent;
	
	private JPanel nPanel, cPanel, sPanel;
	String name = "";
	int count ;
	public ChatClient() {
		
		// TODO Auto-generated constructor stub
		setTitle("채팅프로그램");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		nPanel = new JPanel();
		jlName = new JLabel("대화명");
		
		txtName = new JTextField(20); 
		btnLogin = new JButton("로그인");
		btnLogin.addActionListener(this);
		btnLogout = new JButton("로그아웃");
		btnLogout.addActionListener(this);
		nPanel.add(jlName);nPanel.add(txtName);nPanel.add(btnLogin);
		add(nPanel, "North");
		
		cPanel = new JPanel();
		jtContent = new JTextArea(10, 30);
		jtContent.setEditable(false);
		
		JScrollPane scroll = new JScrollPane(jtContent);
		connecter = new JLabel("접속자 수");
		lbsu = new JLabel(String.valueOf(count));
		cPanel.add(scroll);cPanel.add(connecter);cPanel.add(lbsu);
		add(cPanel, "Center");
		
		sPanel = new JPanel();
		txtContent = new JTextField(25);
		btnOk = new JButton("종료");
		btnOk.addActionListener(this);
		 sPanel.add(btnOk);
		add(sPanel,"South");
		
		
		pack();
		setVisible(true);
		
		txtContent.addActionListener(this);
		
		try {
			socket = new Socket("192.168.0.13", 5000);
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));//서버로부터 값받기
			pw = new PrintWriter(socket.getOutputStream(), true);// 서버로 값넘기기
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "서버에 문제가 있어 접속 불가", "접속 오류", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		Thread t = new Thread(this);
        t.start(); //run 실행
		
     
	}
	
	public static void main(String[] args) {
		ChatClient a=new ChatClient();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == btnLogin) {
			String name = "";
			name = txtName.getText();
			pw.println(name);
			String msg = jtContent.getText();
			jlName.setText("대화명 : " + txtName.getText());
			txtName.setVisible(false);
			txtName.setText("");
			btnLogin.setVisible(false);
			nPanel.add(btnLogout);
			sPanel.add(txtContent);
		}
		else if (e.getSource() == btnOk) {
			String msg = txtContent.getText();
			if(!msg.equals("")) {
				pw.println(msg);
			}
			txtContent.setText("");
		} 
		else if (e.getSource() == txtContent) {
			String msg = txtContent.getText();
			if(!msg.equals("")) {
				pw.println(msg);
			}
			txtContent.setText("");
		} 
		if (e.getSource() == btnLogout) {
			txtName.setText("");
			jtContent.setText("");
			txtName.setVisible(false);
			btnLogin.setVisible(true);
			btnLogout.setVisible(false);
			
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			try {
				String str= br.readLine();
				if(str.indexOf("/e")==0) {
					String mail=str.substring(2);
					count=Integer.parseInt(mail);
					lbsu.setText(String.valueOf(count));
					System.out.print(mail);
				}else if(str.indexOf("/f")==0) {
					String mail=str.substring(2);
					count=Integer.parseInt(mail);
					lbsu.setText(String.valueOf(count));
					
				}else
				jtContent.append(str + "\n");
				jtContent.setCaretPosition(jtContent.getText().length());
				
		
			} catch(IOException e) {
				JOptionPane.showMessageDialog(this, "서버와 연결이 끊어짐", "접속 오류", JOptionPane.ERROR_MESSAGE);
			
				System.exit(0);
			}
		}
	}
	
}
