package chat;

import java.net.*;
import java.util.ArrayList;
import java.io.*;
 
import javax.swing.*;
 
public class ChatServer extends JFrame {
   
	int cout =0;
	 
    JTextArea ta;
    JScrollPane pane;
    ServerSocket ss;
    Socket s;
    ArrayList list;
   
    public ChatServer(){
        super("채팅 서버 v1.0.1");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
       
        ta = new JTextArea();
        pane = new JScrollPane(ta);
        add(pane);
        ta.setText("채팅 서버 시작됨!\n");
       
        setSize(400, 300);
        setVisible(true);
       
        //네트워크 코드
        try{
            list = new ArrayList();
            ss = new ServerSocket(5000);
            while(true){
               
                s = ss.accept(); //접속되어온소켓을 소켓참조변수 s에 담는다.
                ChatThread t = new ChatThread();
                list.add(t); //멀티 쓰레드를 위해
                t.start(); // run 실행
                
            }
        }catch(Exception e){
        	
            e.printStackTrace();
        }
       
       
       
    }//생성자
    class ChatThread extends Thread{
       
        BufferedReader br; //한글OK , 한줄씩 입력 OK
        PrintWriter pw; //한글 OK, 한줄씩 출력 OK
        String nickName;
        public ChatThread(){
            try{
                //입력
                InputStream is = s.getInputStream();
                br = new BufferedReader(new InputStreamReader(is));
               
                //출력
                OutputStream os = s.getOutputStream();
                pw = new PrintWriter(os,true);
                
                               
            }catch(Exception e){
                e.printStackTrace();
            }
           
        }//내부 클래스의 생성자
        public void send(String str) { //채팅내용 전송
            pw.println(str); //채팅내용을 chatclient로 전송
        }
        
        @Override
        public void run(){
        	
            try {
                pw.println("닉네님을 입력하세요."); //채팅내용을 chatclient로 전송
                nickName = br.readLine(); //chatclient에서 pw한것을 br로 받는것
                broadcast(nickName+" 님이 입장했습니다.!");
                
                cout++;
            	String str2 = cout+"";
                broadcast("/e"+str2);
                System.out.println("들어옴");
                ta.append("채팅인원수 : "+cout+"\n");
               
                while(true){
                    String str = br.readLine(); 
                    
                    String str1 = cout+"";
                    broadcast("["+nickName+"] "+str);
                    //[홍길동] 안녕
                    ta.append("[" +nickName+"]"+str+"\n");
                    ta.append("[" +nickName+"]"+str1+"\n");
                    
                }//while
            } catch (Exception e) {
            	cout--;
            	String str1 = cout+"";
            	broadcast("/f"+str1);
            	 ta.append("한명나감\n");
            	 ta.append("채팅인원수 : "+cout+"\n");
                e.printStackTrace();
            }
        }
    }//inner class ChatThread end
    //외부 클래스의 메소드
    public void broadcast(String str){
    	
        for (int i = 0; i < list.size(); i++) {
            ChatThread t = (ChatThread)list.get(i);
            t.send(str);   //리스트가 채팅인원 send해서 각 chatclient로 다보낸다.
        
        }//for
       
    }
    public static void main(String[] args) {
        new ChatServer();
    }//main
   
}//end
