package chat;


import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Client_3{
	
	Socket sc= null;
	PrintWriter pw=null;

	public Frame f1=new Frame("Login");
	public Frame f2=new Frame("대화창");
	//클라이언트 부분
	GridBagLayout Gbag = new GridBagLayout();
	private Label lhost = new Label("Host  주소 : ",Label.CENTER); 
	private Label lport = new Label("Port  번호 : ",Label.CENTER); 
	private Label luser = new Label("User Name : ",Label.CENTER); 
	public static TextField tf1 = new TextField(20);
	public static TextField tf2 = new TextField(10);
	public static TextField tf3 = new TextField(10);
	public  Button btn_in = new Button("접속"); 
	public Button btn_out = new Button("종료");
	
	//채팅창 부분
	public static String host,port,user,str ;
	public Label lb1 = new Label("3조");
	public Label lb2 = new Label("    접속 인원 수 :");
	public int count =0;
	public Label lbsu = new Label(String.valueOf(count));
	public static  TextField  tf4 = new  TextField("문자입력란 입니다~~",20) ;
	public static TextArea  ta = new  TextArea( ) ;
	public  Button  btnsend = new  Button("      전송      ") ;
	public  Button  btnend = new  Button("종료") ;
	public List list = new List(20);
	CheckboxGroup cg=new CheckboxGroup();
	Checkbox chksay1=new Checkbox("귓속말",cg,false);
	Checkbox chksay2=new Checkbox("전체말",cg,true);
	public static Panel pan=new Panel(new BorderLayout(2,2));
	public static Panel p=new Panel(new BorderLayout(2,2));	
	public static Panel p1=new Panel(new BorderLayout());
	public static Panel pp=new Panel(new BorderLayout(2,2));
	public static Panel p2=new Panel(new BorderLayout(2,2));
	public static Panel p3=new Panel(new BorderLayout(2,2));
	public static Panel p4=new Panel(new BorderLayout());
	public static Panel pp2=new Panel(new BorderLayout());
	//클라이언트 부분
	
	public Client_3() {//기본 생성자		
		
	}//생성자 end
	
	class Handler implements ActionListener,FocusListener{
		//IO처리를 위한 메뉴 생성
		private MenuBar mb=new MenuBar();
		private Menu mfile=new Menu("파일");
		private MenuItem mfile_save =new MenuItem("저장");
		private MenuItem mfile_exit =new MenuItem("종료");
		
		private Menu medit=new Menu("편집");
		private Menu mhelp=new Menu("도움말");
		
		
		public void launchFrame(){
			f1.setTitle("Login");
			f1.setLayout(Gbag);
			f1.setBackground(Color.orange);	
	   	
			gbinsert(lhost, 2,5,1,1); 
			gbinsert(tf1,3,5,3,1); 
			gbinsert(lport, 2,6,1,1); 
			gbinsert(tf2, 3,6,3,1); 
			gbinsert(luser, 2,7,1,1); 
			gbinsert(tf3, 3,7,3,1); 
			gbinsert(btn_in, 3,8,1,1);
			gbinsert(btn_out, 4,8,1,1);
			
			f1.pack();
			
			f1.addWindowListener(new WindowAdapter( ) {
				public void windowClosing(WindowEvent we){ System.exit(1) ; }
			}) ;
		
			f1.setBounds(700,300,340,285);
			f1.setResizable(false);
			f1.setVisible(true);
			
			btn_in.addActionListener(this);
			btn_out.addActionListener(this);
			
			mfile_save.addActionListener(this);
			mfile_exit.addActionListener(this);
		}//로그인창 부분 add
		
		public void launchFrame2(){
			//채팅창 오른쪽 화면  
			list.add("*** 접속자 목록 ***");
			p1.add("Center",lb1);		
			p.add("North",p1);
				
			pp.add("North",new Label(" "));
			pp.add("South",new Label(" "));
			pp.add("East",new Label(" "));
			pp.add("West",new Label(" "));
			pp.add("Center",ta);
			p.add("Center",pp);
				
			p2.add("West",new Label(" "));
			p2.add("Center",tf4);
			p2.add("East",btnsend);
			p2.add("South",new Label(" "));
			p.add("South",p2);
			pan.add("East",p);	
			//여기까지 채팅창 오른쪽

			//왼쪽 리스트 목록		
			p4.add("West",lb2);
			p4.add("Center",lbsu);
			p3.add("North",p4);
			
			Panel chkpan = new Panel();
			chkpan.add(chksay1);
			chkpan.add(chksay2);
			pp2.add("North",chkpan);
			pp2.add("South",new Label(" "));
			pp2.add("East",new Label(" "));
			pp2.add("West",new Label(" "));
			pp2.add("Center",list);
			p3.add("Center",pp2);
			//목록
			
			Panel p5=new Panel(new BorderLayout());
			p5.add("East",new Label(" "));
			p5.add("West",new Label(" "));
			p5.add("South",new Label(" "));
			p5.add("Center",btnend);
			p3.add("South",p5);
			pan.add("West",p3);
			//여기까지 왼쪽 리스트 목록
			
			f2.add(pan);
			
			mfile.add(mfile_save); 
			mfile.addSeparator(); mfile.add(mfile_exit);
					
			mb.add(mfile); mb.add(medit); mb.add(mhelp); 
			f2.setMenuBar(mb);//이문장은 반드시 기술
			
			
			tf4.addActionListener(this) ;
			tf4.addFocusListener(this);
			btnsend.addActionListener(this) ;
			btnend.addActionListener(this) ;
			
			f2.addWindowListener(new WindowAdapter( ) {
				public void windowClosing(WindowEvent we){ System.exit(1) ; }
			}) ;
			
			f2.setResizable(false);
			f2.setBackground(Color.orange);
			f2.setBounds(300,200, 650, 500) ;
			f2.setVisible(true) ;		
		}//채팅창 부분 add
		
		
		public void gbinsert(Component c, int x, int y, int w, int h){
		       GridBagConstraints gbc = new GridBagConstraints();
		       gbc.fill= GridBagConstraints.BOTH;
		       gbc.gridx = x; 
		       gbc.gridy = y;
		       gbc.gridwidth = w; 
		       gbc.gridheight = h;
		       gbc.ipadx=10;
		       gbc.anchor = GridBagConstraints.SOUTH;
		       gbc.insets = new Insets(2, 2, 0, 4);
		       Gbag.setConstraints(c,gbc); 
		       f1.add(c);
			 }
		
		public void filesave(){
			try{
			FileWriter fw=new FileWriter("c:\\Mtest\\out.txt");
			BufferedWriter out = new BufferedWriter(fw);
			String data="";
			while(true){
				data=ta.getText();
				if(data==null) break;
				
				out.write(data); 
				out.close();
			}
			}catch(Exception ex){}
		}
		

		@Override
		public void actionPerformed(ActionEvent ae) {
			// TODO Auto-generated method stub
			if(ae.getSource()==btn_in){
				f1.setVisible(false);
				f1.dispose();
				host=tf1.getText();
				port=tf2.getText();
				user=tf3.getText();
				launchFrame2();
				lb1.setText("        "+user+"님 반갑습니다   즐거운 채팅하세용~~♥");
				connect(host,port,user);
			}
			if(ae.getSource()==btnsend||ae.getSource()==tf4){
				sendprocess();
				tf4.setText("");
				tf4.requestFocus();
			}
			if(ae.getSource()==mfile_save){
				filesave();
				JOptionPane.showMessageDialog(null, "저장되었습니다.\n 저장경로(c:\\Mtest\\out.txt)");
			}
			if(ae.getSource()==mfile_exit){System.exit(1);}
			if(ae.getSource()==btnend||ae.getSource()==btn_out){System.exit(1);}
		}//버튼 액션 지정
		
		public void sendprocess(){//텍스트 필드 값을 전송하는 메서드
			try{
				String str2=tf4.getText();
			if(chksay2.getState()==true){//전체말이 체크되어있는 경우
				pw.println(str2);
				System.out.println("보냄  : " + str2);
				}	
			else{//귓속말이 체크된경우
				try{
					String name=list.getSelectedItem();
					pw.println(("/s"+name+"-"+str2));//getByte...?
					System.out.println("보냄  : /s"+name+"-"+str2);
					ta.append(name+"님께 보내는 귓말 ▶▶ "+str2+"\n");
				}catch(Exception ex){ta.append(ex.getMessage());}
			}
		}catch(Exception ex){}
		}

		@Override
		public void focusGained(FocusEvent arg0) {
			// TODO Auto-generated method stub
			tf4.setText("");
		}

		@Override
		public void focusLost(FocusEvent arg0) {
			// TODO Auto-generated method stub
		}
		
	}
	
	public void connect(String host, String port, String user){
		try{
			sc=new Socket(host,Integer.parseInt(port));
			System.out.println("채팅방에 접속하였습니다.");

			ClientThread th = new ClientThread(sc,this);
			th.start();
			
			pw=new PrintWriter(new OutputStreamWriter(sc.getOutputStream()),true);
			pw.println(user);
		}catch(Exception ex){System.out.println(ex.getMessage());}
	}//connect end
	
	//-------------------------------리스트에 이름추가-------------------
	public void addName(String user){
		System.out.println(user+"들와요");
		list.add(user);
	}
	public void removeName(String user){
		System.out.println(user+"나가요");
		list.remove(user);
	}
	//--------------------------------------------------------------
	
	public static void main(String[] args) {
		Client_3 c3 = new Client_3();//생성자 호출
		Client_3.Handler hd=c3.new Handler();//내부클래스 생성자 호출
		hd.launchFrame();//로그인화면 띄우기
	}//main end

	
}//class end

class ClientThread extends Thread{
	Socket sc=null;
	BufferedReader br=null;
	String str;
	String user;
	Client_3 c3;
	
	public ClientThread(Socket sc, Client_3 c3) {
		this.sc=sc;
		this.c3=c3;
	}//생성자 end
	@Override
	public void run() {
		try{
			br= new BufferedReader(new InputStreamReader(sc.getInputStream()));//서버에서 넘어온값 받기
			while(true){
				str=br.readLine();
				System.out.println(str);
				if(str.indexOf("/f")==0){
					user=str.substring(2);
					System.out.println("123 :"+user);
					c3.count++;
					c3.lbsu.setText(String.valueOf(c3.count));
					c3.addName(user);
					
				}
				else if(str.indexOf("/e")==0){
					user=str.substring(2);
					c3.count--;
					c3.lbsu.setText(String.valueOf(c3.count));
					c3.removeName(user);
					
				}
				else{
					c3.ta.append(str+"\n");
				}
			}//while end
		}catch(Exception ex){System.out.println("에러");}
	}//run end
	
}//class end
